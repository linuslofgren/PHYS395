# Running
All questions has not yet been answered. Only Q1 is fully complete.

Make sure that you execute the program using a Python environment which includes `numpy` and `matplotlib`.
This can be created using
```bash
conda create --name <env> --file requirements.txt
conda activate <env>
```

Run the program using
```bash
python Q1.py
python Q3.py
```