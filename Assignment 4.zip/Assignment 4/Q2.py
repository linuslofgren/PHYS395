from math import sqrt

def bisect(f, a, c):
    b = (c+a)/2


    # fa, fb, fc = f(a), f(b), f(c)

    # phi = (1+sqrt(5))/2

    epsilon = 1e-8

    while (c - a) > epsilon:
        print(a, b, c)

        if (b - a) > (c - b):
            d = (b + a)/2
        else:
            d = (c + b)/2

        if f(b) < f(a) and f(b) < f(c):
            a = a
            b = b
            c = d
        else:
            a = b
            b = d
            c = c

    return b

