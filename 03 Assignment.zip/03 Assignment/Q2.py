import numpy as np
from numpy.random import normal, standard_cauchy
from numpy.polynomial.legendre import legvander
import matplotlib.pyplot as plt

N = 2000

x = normal(size=N)

y = x + np.power(x, 2)/6


histogram = np.histogram(y, density=True)


def statistics(samples):
    n = len(samples)
    mean = np.mean(samples)
    median = np.median(samples)
    std = np.sqrt(np.mean(samples**2))
    k=2
    y = np.sort(samples); P = legvander(np.linspace(-1.0, 1.0, n), k)
    L2 = np.sum(y*P[:,k-1])/n

    return mean, median, std, L2

fig, ((f_1)) = plt.subplots(1, 1, figsize=(14, 8))

f_1.hist(y, density=True, bins='auto')
f_1.set_title("Gauss")
plt.savefig("Q2.pdf")